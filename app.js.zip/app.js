// dependencies
const https = require('https');
const express = require('express');
const multer = require('multer');
const queryString = require('query-string');


// app
const app = express();
const storage = multer.memoryStorage();
const upload = multer({storage: storage});

// upload
app.post('/getImageData', upload.single('image'), (req, res) => {
	let params = {		
        	"returnFaceId": "true",
            "returnFaceLandmarks": "false",
            "returnFaceAttributes": "age,gender,headPose,smile,facialHair,glasses,emotion,hair,makeup,occlusion,accessories,blur,exposure,noise",
        };

	let options = {
			host: 'westcentralus.api.cognitive.microsoft.com',
			method: 'POST',
			path: `/face/v1.0/detect?${queryString.stringify(params)}`,
			headers: {
			'Ocp-Apim-Subscription-Key': '45125b24b6fe4f3c9d5c6d0b013b0d55',
			'Content-Type': 'application/octet-stream',
			'Content-Length': req.file.buffer.length
			}
		};

  	const request = https.request(options, response => {
	    res.writeHead(response.statusCode, response.headers);
    	response.pipe(res);
  	});

  	request.write(req.file.buffer);
  	request.end();
});

// start server
let port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`Upload API listening on port ${port}`);
});

module.exports = app;
